package smartherd.com.Modals

//First we declare the data class
data class Hobby(var tittle: String)

object Supplier {
    val hobbies = arrayListOf<String>(
        "Swimming",
        "Eating",
        "Playing"
    )
}

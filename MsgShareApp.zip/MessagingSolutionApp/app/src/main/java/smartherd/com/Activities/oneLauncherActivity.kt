package smartherd.com.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import smartherd.com.R

class oneLauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_one_launcher)

        initall()

    }

    private fun initall() {
        TODO("Not yet implemented")
    }

}

package smartherd.com.AppConstants

object Constants {
    //These are all the constants within our application
    const val USER_MESG_KEY = "message"
}